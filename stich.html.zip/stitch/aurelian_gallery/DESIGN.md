# Design System Document: The Editorial Archive

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Curator"**

This design system is not a template; it is a gallery. It treats every pixel as a deliberate choice in a high-end editorial publication. We move away from the "web-standard" layout of boxes and lines toward a fluid, atmospheric experience that mimics the physical presence of a heavy-stock fashion magazine. 

To break the "bootstrap" look, we utilize **Intentional Asymmetry**. Photography should not always sit centered; it should bleed off-edge or overlap with text to create movement. Our goal is to provide a "quiet luxury" experience where the interface recedes, allowing the photography to command the viewer's absolute attention.

---

## 2. Colors & Tonal Depth
We do not use color to decorate; we use it to direct. The palette is anchored in a deep, nocturnal base with vibrant `primary` accents that act as a signature of quality. The `primary_color_hex` is `#d902ff`, which defines our unique and striking identity.

### The "No-Line" Rule
**1px solid borders for sectioning are strictly prohibited.** To define the end of a section and the start of another, use background color shifts. 
*   *Example:* Transition from `surface` (#131313) to `surface-container-low` (#1c1b1b).
*   *Why:* Borders create visual "noise" that interrupts the eye. Tonal shifts create a seamless flow.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper. 
- **Base Layer:** `background` (#131313)
- **Primary Content Area:** `surface-container` (#201f1f)
- **Floating/Interactive Elements:** `surface-container-high` (#2a2a2a)
- **Nested Detail Cards:** `surface-container-lowest` (#0e0e0e) to create "recessed" depth.

### Signature Textures & Glass
- **The "Accent Wash":** Use a subtle gradient from a lighter primary shade to `primary` (`#d902ff`) for CTAs. This creates a metallic "sheen" rather than a flat plastic look.
- **Glassmorphism:** For navigation bars or floating image captions, use `surface-variant` with a 60% opacity and a `20px backdrop-blur`. This allows the vibrant photography to bleed through the interface, softening the edges.

---

## 3. Typography
Our typographic identity is now unified through the **Public Sans** font family, creating a cohesive and contemporary feel across all elements.

- **Display (Public Sans):** Use `display-lg` and `display-md` for headlines that overlap imagery. Tracking should be slightly tightened (-2%) for a bespoke, printed look.
- **Body (Public Sans):** Use `body-md` for descriptions. We prioritize readability; use a generous line-height (1.6) to ensure the text feels airy and premium.
- **Labels (Public Sans):** Use `label-md` in All-Caps with +10% letter spacing for metadata (e.g., ISO, Aperture, Date). This mimics the technical "fine print" of a gallery exhibit.

---

## 4. Elevation & Depth
In a luxury portfolio, traditional drop shadows are too "digital." We utilize **Tonal Layering**.

- **The Layering Principle:** Depth is achieved by "stacking." A `surface-container-highest` card placed on a `surface` background provides all the "lift" needed without a single shadow.
- **Ambient Shadows:** If an element must float (like a modal), use a "Tonal Shadow." The shadow color must be a transparent version of `surface-container-lowest` with a blur radius of at least `40px`.
- **The Ghost Border:** If a boundary is required for accessibility, use `outline-variant` at **15% opacity**. It should be felt, not seen.
- **The Glow Border:** For circular profile photos, apply a 2px stroke of `primary` (`#d902ff`) with a secondary outer glow (`drop-shadow: 0 0 12px primary_fixed_dim`) to suggest an inner radiance.

---

## 5. Components

### Buttons
- **Primary:** Gradient-filled (`primary` to `primary-container`), no border, maximum (pill-shaped) roundedness, reflecting our `roundedness: 3` token.
- **Tertiary (Ghost):** No background. `label-md` typography. On hover, a subtle `primary` underline appears from the center out.

### Cards & Lists
- **The Gallery Card:** Forbid the use of divider lines. Use `surface-container-low` as the card background against a `surface` page. Separate content with `24px` or `32px` of vertical white space, aligning with our `spacing: 2` scale which indicates normal spacing.
- **Transitions:** Every image hover should involve a subtle scale-up (1.02x) and a shift in the container’s tonal value.

### Inputs
- **Text Fields:** Use the "Minimalist Underline" style. Only the bottom border is visible using `outline-variant`. On focus, the line transforms into the `primary` color (`#d902ff`).

### Custom Component: The "Curator's Loupe"
A bespoke tooltip used on images. Instead of a box, use a semi-transparent `surface-container-highest` circle that follows the cursor, displaying metadata in `label-sm`.

---

## 6. Do’s and Don’ts

### Do:
*   **Use White Space as a Luxury:** Give images room to breathe. Our `spacing: 2` setting encourages a balanced, yet still elevated use of whitespace.
*   **Embrace Asymmetry:** Offset your text blocks from your image grids.
*   **Use Subtle Motion:** All transitions should be `cubic-bezier(0.2, 0, 0, 1)` to feel heavy and deliberate, not "snappy."

### Don't:
*   **Don't use 100% Black:** Pure `#000000` feels "dead." Use our `background` (#131313) for a rich, ink-like depth.
*   **Don't use Dividers:** If you feel the need to draw a line between sections, use a 40px gap of empty space instead.
*   **Don't Over-Animate:** Avoid bouncing or "fun" animations. The vibe is "Still Life," not "Action Movie."